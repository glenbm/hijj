var connection = new WebSocket("ws://localhost:9980");
connection.binaryType = 'arraybuffer';



connection.onopen = function () {

    var data = {
        EventType: ServiceEventType.Connect,
        Data: {
            EventTypes: [
                ServiceEventType.LogMessage,
                ServiceEventType.UserAction,
                ServiceEventType.Configuration,
                ServiceEventType.DeviceModel,
                ServiceEventType.ScreenChanges
            ]
        }
    };

    connection.send(JSON.stringify(data));

    console.log('Connection open!');
}

connection.onclose = function () {
    console.log('Connection closed');
}

connection.onerror = function (error) {
    console.log('Error detected: ' + error);
}

connection.onmessage = function (event) {

    if (event.data instanceof ArrayBuffer) {
        HandleCaptureData(event.data);
        return;
    }

    var jsonStr = event.data;
    var obj = JSON.parse(jsonStr);

    switch (obj.EventType) {
        case ServiceEventType.LogMessage: {
            document.getElementById("webR").value = obj.Data;
            break;
        }
        case ServiceEventType.UserAction: {
            break;
        }
        case ServiceEventType.DeviceModel: {

            if (obj.Data.EventType === InternalDeviceModelInfoType.SlotStatusChanged) {

                var cmd = {
                    device: obj.Data.SimulatorDevice,
                    state: obj.Data.EventName
                };

                document.getElementById("webR").value = JSON.stringify(cmd);
                Instruction(cmd);
            }
            break;
        }
        case ServiceEventType.Configuration: {
            break;
        }
        case ServiceEventType.ScreenChanges: {
            //document.getElementById("cardholder_bg_image").src = 'data:image/bmp;base64, ' + obj.Data.ScreenData;
            break;
        }
    }
}

connection.sendData = function (data) {
    console.log("sent data to the web socket:" + data);
    document.getElementById("webS").value = data;

    connection.send(JSON.stringify(data));
}

// testing
{
    var txtDevice = document.getElementById("device");
    var txtState = document.getElementById("state");

    function changeState(state) {
        var cmd = {
            device: "",
            state: 0
        };
        cmd.device = txtDevice.value;
        cmd.state = state;
        document.getElementById("webR").value = JSON.stringify(cmd);
        Instruction(cmd);
    }
}