#pragma once

#include <windows.h>
#include <atm.h>

namespace StreamerLib
{

}

class WindowDevice
{
public:
    WindowDevice();
    ~WindowDevice();
    HWND hwnd;
    HDC hscreen;
    int width;
    int height;
    int bpp;

    void GetScreenData();
    void GetScreenData(std::string windowName);
    int IsValid();

private:
    void GetDataFromHWND();

    bool fetchedData;

};

WindowDevice::WindowDevice()
{

}

WindowDevice::~WindowDevice()
{
    DeleteDC(hscreen);
    DeleteObject(hwnd);
}

int WindowDevice::IsValid()
{
    if (!fetchedData)
    {
        return 0;
    }

    if (width < 0 || height < 0 || bpp < 0)
    {
        return 0;
    }

    if (hscreen == NULL)
    {
        return 0;
    }

    return 1;
}

void WindowDevice::GetScreenData()
{
    hwnd = GetDesktopWindow();

    GetDataFromHWND();
}

void WindowDevice::GetScreenData(std::string windowName)
{
    LPCWSTR name = (LPCWSTR)windowName.c_str();
    hwnd = ::FindWindow(0, _T("Calculator"));

    GetDataFromHWND();
}

void WindowDevice::GetDataFromHWND()
{
    hscreen = GetDC(hwnd);
    bpp = GetDeviceCaps(hscreen, BITSPIXEL);

    if (bpp >= 32) {
        bpp = 32;
    }
    else if (bpp >= 24 && bpp < 32) {
        bpp = 24;
    }
    else if (bpp >= 16 && bpp < 24) {
        bpp = 16;
    }
    else if (bpp >= 8 && bpp < 16) {
        bpp = 8;
    }
    else if (bpp >= 4 && bpp < 8) {
        bpp = 4;
    }
    else {
        bpp = 2;
    }

    RECT rect;
    GetWindowRect(hwnd, &rect);
    width = rect.right - rect.left;
    height = rect.bottom - rect.top;

    fetchedData = true;
}
