#pragma once
#include "capture.h"

/// <summary>
///  TODO - Summmary for all classes and functions
///  TODO - Sort out public and private variables and add a '_' signature to privates!
///  TODO - When swapping out the screen at run time. Make sure the two buffers are bothed altered equally
/// </summary>
class CaptureStreamer
{
public:
    CaptureStreamer();

    /// <summary>
    /// Initializes Capture Streamer.
    /// </summary>
    /// <param name="window_">The target window_.</param>
    /// <param name="targetHeight">Height of the output capture.</param>
    /// <param name="targetWidth">Width of the  output capture.</param>
    CaptureStreamer(WindowDevice *window_, int targetWidth, int targetHeight)
        :captureOne_(window_, targetWidth, targetHeight),
        captureTwo_(window_, targetWidth, targetHeight)
    {
        currentCapture_ = &captureOne_;
        previousCapture_ = &captureTwo_;
    }

    /// <summary>
    /// Initializes Capture Streamer. Automatically sets the targetWidth and targetHeight to window_ dimensions
    /// </summary>
    /// <param name="window_">The target window_.</param>
    CaptureStreamer(WindowDevice *window_)
        :captureOne_(window_, window_->width, window_->height), 
        captureTwo_(window_, window_->width, window_->height)
    {
        currentCapture_ = &captureOne_;
        previousCapture_ = &captureTwo_;
    }

    ~CaptureStreamer();

    /// <summary>
    /// Captures the current assigned window_.
    /// </summary>
    void CaptureScreen();
    
    /// <summary>
    /// Encodes the capture to a specified format.
    /// </summary>
    /// <param name="type">PNG or JPEG.</param>
    /// <param name="quality">NULL if PNG. 0-100 if JPG.</param>
    void Encode(ImageFormat type, ULONG *quality);
    
    /// <summary>
    /// Saves the previous capture to disk.
    /// </summary>
    /// <param name="path">The path, without the file name. File name is 'targetWidth_targetHeight_quality'.</param>
    /// <param name="type">The type.</param>
    /// <param name="quality">NULL if PNG. 0-100 if JPG.</param>
    void SavePreviousCaptureToDisk(std::wstring path, ImageFormat type, ULONG *quality);
    
    /// <summary>
    /// Alters the size of the output capture.
    /// </summary>
    /// <param name="newWidth">The new target width.</param>
    /// <param name="newHeight">The new target height.</param>
    void AlterSize(int newWidth, int newHeight);
    
    /// <summary>
    /// Gets the capture count.
    /// </summary>
    /// <returns>Returns the number of captures in this session</returns>
    int GetCaptureCount();
    
    /// <summary>
    /// Determines whether [has capture changed].
    /// </summary>
    /// <returns>
    ///   <c>true</c> if [has capture changed]; otherwise, <c>false</c>.
    /// </returns>
    bool HasCaptureChanged();
    
    /// <summary>
    /// Gets the encoded data.
    /// </summary>
    /// <returns>Returns the current held encoded data of current capture.</returns>
    std::vector<unsigned char> GetEncodedData();

private:

    Capture captureOne_, captureTwo_;
    Capture *currentCapture_, *previousCapture_;

    int captureCount_ = 0;

    WindowDevice *window_;

    void SwapBuffers();
    int i = 0, t = 0;
};

CaptureStreamer::CaptureStreamer()
{

}

CaptureStreamer::~CaptureStreamer()
{
    delete currentCapture_;
    delete previousCapture_;
    delete window_;
}

void CaptureStreamer::CaptureScreen()
{
   i +=  currentCapture_->CaptureScreen_TEST();
   std::cout << "capture: " << i / GetCaptureCount() << std::endl;
}

bool CaptureStreamer::HasCaptureChanged()
{
    if (GetCaptureCount() <= 1)
    {
        // can't compare if only one capture has occured
        return true;
    }
    else
    {
        // TODO - store these values in Capture, no need to create every time we check.
        std::vector<unsigned char> bufferOne(currentCapture_->frame.pbits + 40, currentCapture_->frame.pbits + currentCapture_->frame.size);
        std::vector<unsigned char> bufferTwo(previousCapture_->frame.pbits + 40, previousCapture_->frame.pbits + previousCapture_->frame.size);
 
        return (bufferOne != bufferTwo);
    }
}

void CaptureStreamer::SavePreviousCaptureToDisk(std::wstring path, ImageFormat type, ULONG *quality)
{
    previousCapture_->SaveToDisk(path, type, quality);
}

void CaptureStreamer::Encode(ImageFormat type, ULONG *quality)
{
     currentCapture_->Encode(type, quality);
}

std::vector<unsigned char> CaptureStreamer::GetEncodedData()
{
    if (!currentCapture_->IsValid())
    {
        if (!previousCapture_->IsValid())
        {
            return previousCapture_->getEncodedBuffer();
        }
        else
        {
            throw std::exception("No encoded buffers are valid");
        }
    }

    SwapBuffers();
    return previousCapture_->getEncodedBuffer();
}

int CaptureStreamer::GetCaptureCount()
{
    return currentCapture_->GetCaptureCount() + previousCapture_->GetCaptureCount();
}

void CaptureStreamer::AlterSize(int newWidth, int newHeight)
{
    captureOne_.AlterSize(newWidth, newHeight);
    captureTwo_.AlterSize(newWidth, newHeight);
}

void CaptureStreamer::SwapBuffers()
{
    if (currentCapture_ == &captureOne_) {
        currentCapture_ = &captureTwo_;
        previousCapture_ = &captureOne_;
        return;
    }

    currentCapture_ = &captureOne_;
    previousCapture_ = &captureTwo_;
}
