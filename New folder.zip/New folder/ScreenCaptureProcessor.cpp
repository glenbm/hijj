/*******************************************************************************
* � 2017
* Fidelity National Information Services, Inc. and/or its subsidiaries.
* All Rights Reserved worldwide.
* This document is protected under the trade secret and copyright laws as the
* property of Fidelity National Information Services, Inc. and/or its
* subsidiaries. Copying, reproduction or distribution should be limited and
* only to employees with a "need to know" to do their job. Any disclosure of
* this document to third parties is strictly prohibited.
*******************************************************************************/

#include "atm.h"
#include "ScreenCaptureProcessor.h"

#include "CaptureStreamer.h"
#include "WindowDevice.h"

ScreenCaptureProcessor::ScreenCaptureProcessor(std::shared_ptr<ITracing> tracer) : tracer_(tracer) { }

ScreenCaptureProcessor::~ScreenCaptureProcessor()
{
    StopScreenCapture();
}

void ScreenCaptureProcessor::StartScreenCapture()
{
    // mutex to ensure we aren't currently in the process of stopping (or starting)
    threadMutex_.lock();

    if (screenCaptureThread_ == nullptr)
    {
        stopScreenCaptureFlag_ = false;

        // INIT

        // start the background thread
        screenCaptureThread_ = std::make_unique<std::thread>(
            &ScreenCaptureProcessor::ScreenCaptureThreadHandler,
            this);
    }

    threadMutex_.unlock();
}

void ScreenCaptureProcessor::StopScreenCapture()
{
    // mutex to ensure we aren't currently in the process of starting (or stopping)
    threadMutex_.lock();

    if (screenCaptureThread_ != nullptr)
    {
        stopScreenCaptureFlag_ = true;

        tracer_->debug("ScreenCaptureProcessor.StopScreenCapture about to wait for thread to complete");

        screenCaptureThread_->join();

        tracer_->debug("ScreenCaptureProcessor.StopScreenCapture thread finished, resetting all");

        screenCaptureThread_.reset(nullptr);
    }

    threadMutex_.unlock();
}

void ScreenCaptureProcessor::ScreenCaptureThreadHandler()
{
    int sleeptime = 1;

    // Create window and initalize it
    //TODO - Simple custom GetScreenData to pass in a (enum?)(int?) that lets you pick any monitor to stream from
    WindowDevice window;
    window.GetScreenData();

    // Create streamer and initalize it, passing a reference to the desired window

    CaptureStreamer streamer(&window, 1536, 864);
    //CaptureStreamer streamer(&window, 1152, 768);
    //CaptureStreamer streamer(&window, 768,  432);
    //CaptureStreamer streamer(&window, 334,  216);

    while (true)
    {
        if (stopScreenCaptureFlag_)
        {
            break;
        }

        try
        {
            streamer.CaptureScreen();

            //streamer.Encode(ImageFormat::PNG, NULL);
            streamer.Encode(ImageFormat::JPG, (ULONG*)70);

            //if (streamer.HasCaptureChanged())
            //{
                OnScreenChanged(streamer.GetEncodedData());
            //}

        }
        catch (const std::exception& ex)
        {
            std::stringstream ss;
            ss << "Exception caught in ScreenCaptureProcessor.ScreenCaptureThreadHandler (" << ex.what() << ")";
            tracer_->error(ss.str());
        }
        catch (...)
        {
            tracer_->fatal("Unknown error caught in ScreenCaptureProcessor.ScreenCaptureThreadHandler");
            break;  // stop at this point as an unhandled exception has occurred
        }

        if (stopScreenCaptureFlag_)
        {
            break;
        }

        Sleep(sleeptime);
    }

    tracer_->debug("ScreenCaptureProcessor.ScreenCaptureThreadHandler exiting thread");
}
