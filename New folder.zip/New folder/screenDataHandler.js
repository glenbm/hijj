var frameCount = 0;
var delta = 0;

var lastCalledTime;
var fps;

var imgHolder = document.getElementById("cardholder_bg_image");

var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");
var img = new Image();

img.onload = function () {
    ctx.drawImage(img, 0, 0);

    img.src = "";
}   

function arrayToBase64String(a) {
    return btoa(new Uint8Array(a).reduce((data, byte) => data + String.fromCharCode(byte), ''));
}

async function HandleCaptureData(screenData) {

    if (!lastCalledTime) {
        lastCalledTime = Date.now();
        fps = 0;
    }

    imgHolder.src = "data:image/png;base64, " + arrayToBase64String(screenData);

    delta += (Date.now() - lastCalledTime) / 1000;
    lastCalledTime = Date.now();
    fps = 1 / (delta / frameCount);

    frameCount++;
    
    //print every 30 frames
    if (frameCount > 999  && frameCount % 100 == 0 && frameCount < 2099)  {
        console.log('frame-count: ' + frameCount + ', frame-rate: ' + fps);
    }
}
